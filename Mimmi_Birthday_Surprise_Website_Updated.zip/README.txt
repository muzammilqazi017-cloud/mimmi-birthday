MIMMI BIRTHDAY SURPRISE

1. Open index.html to preview.
2. Put 4-5 photos in the images folder and name them:
   photo1.jpg
   photo2.jpg
   photo3.jpg
   photo4.jpg
   (You can add photo5 later by editing index.html.)
3. Secret answer is currently: mimmi
4. Voice note is intentionally NOT included because you selected No.
5. To publish free, upload the whole folder to a GitHub repository and enable GitHub Pages.

IMPORTANT:
- Replace the placeholder photos with your chosen photos.
- The website is mobile-first.
- To change text, edit index.html.
